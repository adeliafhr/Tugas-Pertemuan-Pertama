/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pertemuanpertama.pkg1;

/**
 *
 * @author Lenovo
 */
public class Hewan extends MakhlukHidup {
     private int JumlahKaki;
     private String CaraBergerak;
     private String Makanan;

    /**
     * @return the JumlahKaki
     */
    public int getJumlahKaki() {
        return JumlahKaki;
    }

    /**
     * @param JumlahKaki the JumlahKaki to set
     */
    public void setJumlahKaki(int JumlahKaki) {
        this.JumlahKaki = JumlahKaki;
    }

    /**
     * @return the CaraBergerak
     */
    public String getCaraBergerak() {
        return CaraBergerak;
    }

    /**
     * @param CaraBergerak the CaraBergerak to set
     */
    public void setCaraBergerak(String CaraBergerak) {
        this.CaraBergerak = CaraBergerak;
    }

    /**
     * @return the Makanan
     */
    public String getMakanan() {
        return Makanan;
    }

    /**
     * @param Makanan the Makanan to set
     */
    public void setMakanan(String Makanan) {
        this.Makanan = Makanan;
    }
}
