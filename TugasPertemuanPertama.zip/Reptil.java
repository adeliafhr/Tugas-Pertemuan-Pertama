/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pertemuanpertama.pkg1;

/**
 *
 * @author Lenovo
 */
public class Reptil extends Hewan {
    private String Reproduksi;
    private String Berkulit;
    private String BentukKaki;

    /**
     * @return the Berkembangbiak
     */
    public String getReproduksi() {
        return Reproduksi;
    }

    /**
     * @param Reproduksi the Berkembangbiak to set
     */
    public void setReproduksi(String Reproduksi) {
        this.Reproduksi = Reproduksi;
    }

    /**
     * @return the Berkulit
     */
    public String getBerkulit() {
        return Berkulit;
    }

    /**
     * @param Berkulit the Berkulit to set
     */
    public void setBerkulit(String Berkulit) {
        this.Berkulit = Berkulit;
    }

    /**
     * @return the BentukKaki
     */
    public String getBentukKaki() {
        return BentukKaki;
    }

    /**
     * @param BentukKaki the BentukKaki to set
     */
    public void setBentukKaki(String BentukKaki) {
        this.BentukKaki = BentukKaki;
    }
}
