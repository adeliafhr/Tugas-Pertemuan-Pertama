/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pertemuanpertama.pkg1;

/**
 *
 * @author Lenovo
 */
public class Pisces extends Hewan {
    private int JumlahSirip;
    private String BentukSirip;

    /**
     * @return the BentukSirip
     */
    public String getBentukSirip() {
        return BentukSirip;
    }

    /**
     * @param BentukSirip the BentukSirip to set
     */
    public void setBentukSirip(String BentukSirip) {
        this.BentukSirip = BentukSirip;
    }

    /**
     * @return the JumlahSirip
     */
    public int getJumlahSirip() {
        return JumlahSirip;
    }

    /**
     * @param JumlahSirip the JumlahSirip to set
     */
    public void setJumlahSirip(int JumlahSirip) {
        this.JumlahSirip = JumlahSirip;
    }
}
