/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pertemuanpertama.pkg1;

/**
 *
 * @author Lenovo
 */
public class Monokotil extends Tumbuhan {
    private String BentukBuah;
    private String SistemPerakaran;
    private String Habitat;

    /**
     * @return the BentukBuah
     */
    public String getBentukBuah() {
        return BentukBuah;
    }

    /**
     * @param BentukBuah the BentukBuah to set
     */
    public void setBentukBuah(String BentukBuah) {
        this.BentukBuah = BentukBuah;
    }

    /**
     * @return the SistemPerakaran
     */
    public String getSistemPerakaran() {
        return SistemPerakaran;
    }

    /**
     * @param SistemPerakaran the SistemPerakaran to set
     */
    public void setSistemPerakaran(String SistemPerakaran) {
        this.SistemPerakaran = SistemPerakaran;
    }

    /**
     * @return the Habitat
     */
    public String getHabitat() {
        return Habitat;
    }

    /**
     * @param Habitat the Habitat to set
     */
    public void setHabitat(String Habitat) {
        this.Habitat = Habitat;
    }
}
