/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pertemuanpertama.pkg1;

/**
 *
 * @author Lenovo
 */
public class Dikotil extends Tumbuhan {
    private String BentukBatang;
    private String BentukBiji;
    private String TulangDaun;

    /**
     * @return the BentukBatang
     */
    public String getBentukBatang() {
        return BentukBatang;
    }

    /**
     * @param BentukBatang the BentukBatang to set
     */
    public void setBentukBatang(String BentukBatang) {
        this.BentukBatang = BentukBatang;
    }

    /**
     * @return the BentukBiji
     */
    public String getBentukBiji() {
        return BentukBiji;
    }

    /**
     * @param BentukBiji the BentukBiji to set
     */
    public void setBentukBiji(String BentukBiji) {
        this.BentukBiji = BentukBiji;
    }

    /**
     * @return the TulangDaun
     */
    public String getTulangDaun() {
        return TulangDaun;
    }

    /**
     * @param TulangDaun the TulangDaun to set
     */
    public void setTulangDaun(String TulangDaun) {
        this.TulangDaun = TulangDaun;
    }
}
