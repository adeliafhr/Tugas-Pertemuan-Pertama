/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pertemuanpertama.pkg1;

/**
 *
 * @author Lenovo
 */
public class Amfibi extends Hewan {
    private String JenisKulit;
    private String Bernafas;
    private String Habitat;

    /**
     * @return the JenisKulit
     */
    public String getJenisKulit() {
        return JenisKulit;
    }

    /**
     * @param JenisKulit the JenisKulit to set
     */
    public void setJenisKulit(String JenisKulit) {
        this.JenisKulit = JenisKulit;
    }

    /**
     * @return the Bernafas
     */
    public String getBernafas() {
        return Bernafas;
    }

    /**
     * @param Bernafas the Bernafas to set
     */
    public void setBernafas(String Bernafas) {
        this.Bernafas = Bernafas;
    }

    /**
     * @return the Habitat
     */
    public String getHabitat() {
        return Habitat;
    }

    /**
     * @param Habitat the Reproduksi to set
     */
    public void setHabitat(String Habitat) {
        this.Habitat = Habitat;
    }
    
}
