/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pertemuanpertama.pkg1;

/**
 *
 * @author Lenovo
 */
public class Tumbuhan extends MakhlukHidup {
    private String WarnaDaun;
    private String ArahDaun;
    private String JenisAkar;
    private String JenisBiji;

    /**
     * @return the WarnaDaun
     */
    public String getWarnaDaun() {
        return WarnaDaun;
    }

    /**
     * @param WarnaDaun the WarnaDaun to set
     */
    public void setWarnaDaun(String WarnaDaun) {
        this.WarnaDaun = WarnaDaun;
    }

    /**
     * @return the ArahDaun
     */
    public String getArahDaun() {
        return ArahDaun;
    }

    /**
     * @param ArahDaun the ArahDaun to set
     */
    public void setArahDaun(String ArahDaun) {
        this.ArahDaun = ArahDaun;
    }

    /**
     * @return the JenisAkar
     */
    public String getJenisAkar() {
        return JenisAkar;
    }

    /**
     * @param JenisAkar the JenisAkar to set
     */
    public void setJenisAkar(String JenisAkar) {
        this.JenisAkar = JenisAkar;
    }

    /**
     * @return the JenisBiji
     */
    public String getJenisBiji() {
        return JenisBiji;
    }

    /**
     * @param JenisBiji the JenisBiji to set
     */
    public void setJenisBiji(String JenisBiji) {
        this.JenisBiji = JenisBiji;
    }
}
