 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pertemuanpertama.pkg1;

/**
 *
 * @author Lenovo
 */
public class Aves extends Hewan {
    private int JumlahSayap;
    private String BentukTubuh;

    /**
     * @return the JumlahSayap
     */
    public int getJumlahSayap() {
        return JumlahSayap;
    }

    /**
     * @param JumlahSayap the JumlahSayap to set
     */
    public void setJumlahSayap(int JumlahSayap) {
        this.JumlahSayap = JumlahSayap;
    }

    /**
     * @return the BentukTubuh
     */
    public String getBentukTubuh() {
        return BentukTubuh;
    }

    /**
     * @param BentukTubuh the Terbang to set
     */
    public void setBentukTubuh(String BentukTubuh) {
        this.BentukTubuh = BentukTubuh;
    }
    
}
